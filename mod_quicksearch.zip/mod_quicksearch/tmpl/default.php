<?php
defined('_JEXEC') or die;
?>

<form method="get" action="index.php" class="filter-form"
      style="padding:20px; border:1px solid #ccc; border-radius:10px; max-width:400px; width:100%; box-sizing:border-box;">

    <h4 style="margin-bottom:15px;">🔍 <strong>Lọc sản phẩm</strong></h4>

    <!-- Giá từ -->
    <div style="margin-bottom: 20px;">
        <label for="priceMin" style="font-weight: 500;">Giá từ:</label>
        <div style="position: relative;">
            <span id="labelMin"
                  style="position: absolute; top: -25px; right: 0; background: #003d99; color: #fff; padding: 2px 6px; border-radius: 4px; font-size: 12px;">
                <?= number_format($minPrice, 0, ',', '.') ?> đ
            </span>
            <input type="range" id="priceMin" name="price_min" min="0" max="<?= $maxSliderPrice ?>"
                   step="1000000" value="<?= $minPrice ?>" oninput="updateRangeSlider()" style="width: 100%;"/>
        </div>
    </div>

    <!-- Giá đến -->
    <div style="margin-bottom: 20px;">
        <label for="priceMax" style="font-weight: 500;">Giá đến:</label>
        <div style="position: relative;">
            <span id="labelMax"
                  style="position: absolute; top: -25px; right: 0; background: #003d99; color: #fff; padding: 2px 6px; border-radius: 4px; font-size: 12px;">
                <?= number_format($maxPrice, 0, ',', '.') ?> đ
            </span>
            <input type="range" id="priceMax" name="price_max" min="0" max="<?= $maxSliderPrice ?>"
                   step="1000000" value="<?= $maxPrice ?>" oninput="updateRangeSlider()" style="width: 100%;"/>
        </div>
    </div>

    <!-- Checkbox cho hãng sản phẩm -->
    <?php if (!empty($brands)) : ?>
        <div style="margin-bottom: 15px;">
            <label style="font-weight: 500;">Chọn hãng:</label>
            <div style="border: 1px solid #ccc; padding: 10px; max-height: 150px; overflow-y: auto; border-radius: 6px;">
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 6px;">
                    <?php foreach ($brands as $i => $brand) : 
                        $inputId = 'brand_' . $i;
                        $checked = in_array($brand, $selectedBrands) ? 'checked' : '';
                        ?>
                        <div>
                            <input type="checkbox" id="<?= $inputId ?>" name="brands[]" value="<?= htmlspecialchars($brand) ?>" <?= $checked ?> />
                            <label for="<?= $inputId ?>"><?= htmlspecialchars($brand) ?></label>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- Nút lọc -->
    <button type="submit"
            style="padding: 8px 20px; background-color: #003d99; color: white; border: none; border-radius: 6px;">
        Lọc
    </button>

</form>

<script>
    function updateRangeSlider() {
        const min = document.getElementById("priceMin");
        const max = document.getElementById("priceMax");
        const labelMin = document.getElementById("labelMin");
        const labelMax = document.getElementById("labelMax");

        // Đảm bảo min không vượt quá max
        if (parseInt(min.value) > parseInt(max.value)) {
            min.value = max.value;
        }

        labelMin.textContent = Number(min.value).toLocaleString('vi-VN') + ' đ';
        labelMax.textContent = Number(max.value).toLocaleString('vi-VN') + ' đ';
    }

    window.onload = updateRangeSlider;
</script>
