<?php
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Helper\ModuleHelper;

// Lấy ứng dụng và input
$app = Factory::getApplication();
$input = $app->input;

// Lấy tham số cấu hình từ backend
$maxSliderPrice = (int) $params->get('max_price', 71000000);
$brandsList = $params->get('brands', '');

// Tách chuỗi brands thành mảng
$brands = array_filter(array_map('trim', explode("\n", $brandsList)));

// Lấy tham số từ GET để giữ trạng thái filter
$minPrice = $input->getInt('price_min', 0);
$maxPriceInput = $input->getInt('price_max', 0);

// Giới hạn maxPrice không vượt quá maxSliderPrice
$maxPrice = ($maxPriceInput > 0 && $maxPriceInput <= $maxSliderPrice) ? $maxPriceInput : $maxSliderPrice;

// Lấy mảng brands đã chọn
$selectedBrands = $input->get('brands', [], 'array');

// Gửi biến xuống layout
require ModuleHelper::getLayoutPath('mod_quicksearch', $params->get('layout', 'default'));
