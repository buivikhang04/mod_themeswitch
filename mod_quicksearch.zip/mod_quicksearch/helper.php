<?php
defined('_JEXEC') or die;

class ModQuickSearchHelper {
    // Hiện tại không cần xử lý nâng cao
}
